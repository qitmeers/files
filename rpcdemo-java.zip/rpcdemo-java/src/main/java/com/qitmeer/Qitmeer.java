package com.qitmeer;

import java.util.Base64;

public class Qitmeer {
	static final String url = "https://127.0.0.1:8131";
	static final String usr = "admin";
	static final String pass = "123456";
	
	public static String getBlockByOrder(int order,boolean show) {
		String jsonStr = "{\"id\":\"1\",\"method\":\"getBlockByOrder\",\"jsonrpc\":\"jsonrpc\",\"params\":["+order+","+show+"]}";
		String rep = HttpClientUtil.doPost(url, jsonStr, "utf-8",authorization());
		return rep;
	}
	
	public static String authorization(){
		Base64.Encoder encoder = Base64.getEncoder();
		String encodeStr = usr.concat(":").concat(pass);
		String encodedText = encoder.encodeToString(encodeStr.getBytes());
		return "Basic ".concat(encodedText);
	}
	
	public static void main(String[] args) {
        
        System.out.println(getBlockByOrder(30,true));
	}

}
